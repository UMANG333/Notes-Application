package com.example.notes_application_android.Util;

import android.view.View;

public interface ItemClickListener {
    public void onItemClick(View view, int position, boolean isLongClick);
}
